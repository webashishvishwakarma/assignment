const boxElement = document.getElementById("box");

// add a mouseover event listener to the element
boxElement.addEventListener("mouseover", function () {
  alert(
    "you entered in Restricted Area 🙅 (mouse over event is working properly)"
  );
});