const boxElement = document.getElementById("box");

// add a click event listener to the element
boxElement.addEventListener("click", function () {
  alert("you just clicked me 👍");
});