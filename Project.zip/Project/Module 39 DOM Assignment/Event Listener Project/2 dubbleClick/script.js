const boxElement = document.getElementById("box");

// adding a dblclick event listener to the element
boxElement.addEventListener("dblclick", function () {
  alert("doubleClick event is working properly 👍");
});